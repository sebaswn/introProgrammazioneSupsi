class Dice{
  public int rollDice(){
    return  1+(int)(Math.random()*6);
  }
}
